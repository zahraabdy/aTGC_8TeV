# This file was automatically created by FeynRules 2.3.32
# Mathematica version: 11.2.0 for Linux x86 (32-bit) (September 11, 2017)
# Date: Fri 5 Apr 2019 00:05:08


from object_library import all_couplings, Coupling

from function_library import complexconjugate, re, im, csc, sec, acsc, asec, cot



